package eshop.homedecor.shopapi.enums;

/**
 * Created By Praveen
 */
public interface CodeEnum {
    Integer getCode();

}
