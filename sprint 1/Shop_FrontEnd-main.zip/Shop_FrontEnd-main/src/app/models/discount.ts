export class Discount {
    id:string;
    status:number;
}
